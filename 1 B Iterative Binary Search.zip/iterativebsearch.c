#include<stdio.h>
int main()
{
   int  l,r,a, mid,n, searchelement, ar[150];
   scanf("%d",&n); 
   for (a= 0; a< n; a++)
      scanf("%d",&ar[a]); 
   scanf("%d", &searchelement);
   l= 0;
   r= n - 1;
   mid = (l+r)/2;
   while (l <= r) {
      if (ar[mid] < searchelement)
         l= mid + 1;    
      else if (ar[mid] == searchelement) {
         printf("The number found at the index %d", mid);
         break;
      }
      else
         r = mid-1;
      mid = (l+ r)/2;
   }
   if (l > r)
      printf("%d",-1);
   return 0;
}