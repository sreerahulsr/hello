#include <stdio.h>
int rbs(int a[], int low, int high, int m)
    {
        if (high >= low)
            {
                int mid = low + (high - low) / 2;
                if (a[mid] == m)
                return mid;
                if(a[mid] > m)
                return rbs(a, low, mid - 1, m);
                return rbs(a, mid + 1, high, m);
            }
        return -1;
    }
int main(void)
    {
        int a[20], i,m,b;
        printf("Enter number of elements : ");
        scanf("%d",&b);
        printf("enter elements :");
        for(i=0;i<b;i++)
            {
            scanf(" %d",&a[i]);
            }
        printf(" n");
        int n = sizeof(a[0]);
        printf("Enter the number to be searched :");
        scanf("%d", &m);
        int r = rbs(a, 0, b-1, m);
        while(r == -1)
            {
            printf("-1 :");
            break;
            }
        printf(" %d",r);
        return 0;
}